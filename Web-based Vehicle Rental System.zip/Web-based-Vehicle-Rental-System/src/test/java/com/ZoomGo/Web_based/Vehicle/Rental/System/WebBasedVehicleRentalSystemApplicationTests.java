package com.ZoomGo.Web_based.Vehicle.Rental.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebBasedVehicleRentalSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
