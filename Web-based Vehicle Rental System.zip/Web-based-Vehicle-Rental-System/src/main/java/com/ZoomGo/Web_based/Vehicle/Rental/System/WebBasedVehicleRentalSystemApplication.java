package com.ZoomGo.Web_based.Vehicle.Rental.System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebBasedVehicleRentalSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebBasedVehicleRentalSystemApplication.class, args);
	}

}
