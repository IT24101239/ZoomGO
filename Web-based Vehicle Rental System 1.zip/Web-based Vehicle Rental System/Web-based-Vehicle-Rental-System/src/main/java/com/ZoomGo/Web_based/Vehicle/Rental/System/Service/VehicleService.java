package com.ZoomGo.Web_based.Vehicle.Rental.System.Service;

import com.ZoomGo.Web_based.Vehicle.Rental.System.Model.Vehicle;
import com.ZoomGo.Web_based.Vehicle.Rental.System.Repo.VehicleRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehicleService {

    @Autowired
    private VehicleRepo vehicleRepo;

    // Get all vehicles
    public List<Vehicle> getAllVehicles() {
        return vehicleRepo.findAll();
    }

    // Save or update vehicle
    public void saveVehicle(Vehicle vehicle) {
        vehicleRepo.save(vehicle);
    }

    // Delete vehicle by ID
    public void deleteVehicle(int id) {
        vehicleRepo.deleteById(id);
    }

    // Get vehicle by ID
    public Vehicle getVehicleById(int id) {
        return vehicleRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Vehicle not found with id: " + id));
    }
}
